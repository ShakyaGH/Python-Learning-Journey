from datetime import datetime
from random import randint

# Emoji variables to use in your project
world = "🌍🌎🌏"
python = "Python 🐍"
fire = "🔥"

# Emojis to copy and paste into your code:
# 🎊 🙌 🙌🏼 🙌🏽 🙌🏾 🙌🏿 # 😃 🕒 🎨 🎮 🔬 🎉 🕶️ 🎲 😊
# 👩‍🦽 👩🏼‍🦽 👩🏽‍🦽 👩🏾‍🦽 👩🏿‍🦽 🧘 🧘🏼 🧘🏽 🧘🏾 🧘🏿 🙋 🙋🏼 🙋🏽 🙋🏾 🙋🏿
# 🦄 🚀 💯 ⭐ 💛 ❤️ 📚 ⚽ 🏏 🏀 🥋 🏆 ✨ 🥺 🌈 🔥 ♻️ 🌳

# Useful characters :',()*_/.#


# Function definitions
def roll_dice():
    while True:
        max = int(input("How many sides in your dice, "))
        print(f"Your dice has, {max} sides")
        roll = randint(1,max)
        print("Let's roll the dice")
        X = input("Do you want to roll the dice?(y/n)")
        if X == "y":
            print(f"You rolled a, {roll}")
        elif X == "n":
            print("Ok. Let's exit the programme")
            break
        else:
            print("Something went wrong")
            continue
        
    
# Put code to run under here

print("Hello")
print(f"Hello{world}")
print(f"Welcome to {python}")
print(f"{python} is good at Math!")
print(660*138)
print(f"The Date & Time is, {datetime.now()} ")



print("--------------------------------------------")

roll_dice()
